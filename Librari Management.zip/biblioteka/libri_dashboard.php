<!DOCTYPE html>
<html lang="sq">
<head>
  <meta charset="UTF-8" />
  <title>Paneli i Librave</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0; 
      padding: 0; 
      background: #f9f9f9;

      /* Këto i shtojmë për footer në fund */
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    .main-content {
      max-width: 1000px;
      margin: 30px auto;
      padding: 0 20px;
      background: white;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      border-radius: 8px;
      flex-grow: 1; /* që të marrë hapësirë dhe shtyjë footer në fund */
    }

    .navbar {
      background-color: #1e3d59;
      color: white;
      display: flex;
      justify-content: space-between;
      padding: 15px 30px;
      align-items: center;
    }
    .logo {
      font-size: 1.5em;
    }
    .nav-links {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
    }
    .nav-links li {
      margin-left: 20px;
    }
    .nav-links a {
      color: #ecf0f1;
      text-decoration: none;
      font-weight: 600;
      padding: 8px 12px;
      border-radius: 6px;
      transition: background-color 0.3s ease;
    }
    .nav-links a:hover {
      background-color: #f4f6f8;
    }

    /* Chatbot */
    .chatbot-container {
      position: fixed;
      bottom: 25px;
      right: 25px;
      width: 320px;
      max-width: 90vw;
      background: white;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.25);
      overflow: hidden;
      font-size: 14px;
      display: flex;
      flex-direction: column;
      user-select: none;
      z-index: 1000;
    }
    .chatbot-header {
      background-color: #1e3d59;
      color: white;
      padding: 14px 20px;
      font-weight: 700;
      cursor: pointer;
      user-select: none;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .chatbot-header span {
      user-select: none;
    }
    .chatbot-body {
      display: none;
      flex-direction: column;
      height: 200px;
      padding: 15px 20px;
      overflow-y: auto;
      background-color: #f0f4f8;
    }
    .chatbot-body.active {
      display: flex;
    }
    #chatMessages {
      flex-grow: 1;
      overflow-y: auto;
      margin-bottom: 12px;
      scrollbar-width: thin;
      scrollbar-color: #a5d6a7 transparent;
    }
    #chatMessages::-webkit-scrollbar {
      width: 6px;
    }
    #chatMessages::-webkit-scrollbar-thumb {
      background-color: #a5d6a7;
      border-radius: 10px;
    }
    .chat {
      padding: 10px 14px;
      border-radius: 20px;
      max-width: 85%;
      margin-bottom: 10px;
      word-wrap: break-word;
      line-height: 1.3;
      font-size: 14px;
    }
    .user {
      background-color: #dfe6e9;
      align-self: flex-end;
      border-bottom-right-radius: 4px;
    }
    .bot {
      background-color: #a5d6a7;
      align-self: flex-start;
      border-bottom-left-radius: 4px;
    }
    #userInput {
      border: 1px solid #ccc;
      border-radius: 25px;
      padding: 10px 18px;
      font-size: 14px;
      width: 100%;
      outline: none;
      transition: border-color 0.3s ease;
    }
    #userInput:focus {
      border-color: #2a9d8f;
    }

    h2 {
      color: #2c3e50;
    }
    ul {
      padding-left: 20px;
    }
    table.book-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 15px;
    }
    table.book-table th, table.book-table td {
      border: 1px solid #ddd;
      padding: 8px;
      text-align: left;
    }
    table.book-table th {
      background-color: #2980b9;
      color: white;
    }
    table.book-table tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    
    /* Footer styles */
    footer {
      background-color: #2c3e50;
      color: #dbe9f4;
      text-align: center;
      padding: 25px 20px;
      border-top: 1px solid #dbe9f4;
      font-size: 16px;
      font-weight: 500;
      width: 100%;
      box-sizing: border-box;
    }

    footer a {
      color: #ffffff;
      text-decoration: none;
      font-weight: 700;
      transition: color 0.3s ease;
    }

    footer a:hover {
      color: #ffbfa3;
      text-decoration: underline;
    }

    footer .footer-inner {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 15px;
    }

    .footer-logo {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      justify-content: center;
    }

    .footer-logo svg {
      width: 20px;
      height: 20px;
      fill: #ffbfa3;
    }
  </style>
</head>
<body>

  <nav class="navbar">
    <div class="logo">📚 Paneli i Anëtarit</div>
    <ul class="nav-links">
      <li><a href="#llojet">Llojet e Librave</a></li>
      <li><a href="#aktivitete">Aktivitetet</a></li>
      <li><a href="kerkese_huazimi.html">Kerkese per huazim</a></li>
      <li><a href="index.html">Log out</a></li>
    </ul>
  </nav>

  <div class="main-content">

    <section id="llojet">
      <h2>Llojet e Librave</h2>
      <ul>
        <li>Histori Ushtarake
          <ul>
            <li>Historia e Ushtrise Shqiptare</li>
            <li>Historia e Forcave Ajrore</li>
          </ul>
        </li>
        <li>Strategji Ushtarake
          <ul>
            <li>Taktikat Ushtarake</li>
            <li>Doktrina dhe Strategji</li>
          </ul>
        </li>
        <li>Manual Trajnimi</li>
        <li>Biografi</li>
        <li>Misione dhe Operacione</li>
      </ul>
    </section>

    <?php
    // Lidhja me databazën
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "biblioteka";

    $conn = new mysqli($host, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Lidhja me databazën dështoi: " . $conn->connect_error);
    }

    // Query për librat me emrin e plotë të autorit dhe përshkrimin e llojit
    $sql = "SELECT 
              L.titulli, L.ISBN, L.viti_botimit, 
              CONCAT(A.emri, ' ', A.mbiemri) AS autori,
              LL.pershkrimi_lloji AS lloji
            FROM Libri L
            INNER JOIN Autori A ON L.id_autori = A.id_autori
            INNER JOIN Lloji LL ON L.id_lloji = LL.id_lloji
            ORDER BY L.titulli ASC";

    $result = $conn->query($sql);
    ?>

    <section id="librat">
      <h2>📚 Lista e Librave</h2>
      <table class="book-table">
        <thead>
          <tr>
            <th>Titulli</th>
            <th>Autori</th>
            <th>Lloji</th>
            <th>Viti i Botimit</th>
            <th>ISBN</th>
          </tr>
        </thead>
        <tbody>
          <?php
          if ($result && $result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  echo "<tr>
                          <td>" . htmlspecialchars($row['titulli']) . "</td>
                          <td>" . htmlspecialchars($row['autori']) . "</td>
                          <td>" . htmlspecialchars($row['lloji']) . "</td>
                          <td>" . htmlspecialchars($row['viti_botimit']) . "</td>
                          <td>" . htmlspecialchars($row['ISBN']) . "</td>
                        </tr>";
              }
          } else {
              echo "<tr><td colspan='5'>Asnjë libër i regjistruar.</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </section>

    <section id="aktivitete">
      <h2>Aktivitetet e Afërta</h2>
      <ul>
        <?php
        // Query për aktivitetet planifikuara ose në zbatim
        $aktivitetetQuery = "
          SELECT 
            titulli_aktivitetit, pershkrimi_aktivitetit, data, ora, vendi, organizatori
          FROM Aktiviteti
          WHERE statusi_aktivitetit IN ('planifikuar', 'ne_zhvillim')
          ORDER BY data ASC, ora ASC
          LIMIT 5
        ";
        $aktivitetetResult = $conn->query($aktivitetetQuery);

        if ($aktivitetetResult && $aktivitetetResult->num_rows > 0) {
            while ($aktivitet = $aktivitetetResult->fetch_assoc()) {
                $dataFormat = date("d F Y", strtotime($aktivitet['data']));
                $oraFormat = date("H:i", strtotime($aktivitet['ora']));

                echo "<li>
                        <strong>" . htmlspecialchars($aktivitet['titulli_aktivitetit']) . "</strong><br>
                        📅 " . htmlspecialchars($dataFormat) . " ora " . htmlspecialchars($oraFormat) . "<br>
                        Vendi: " . htmlspecialchars($aktivitet['vendi']) . "<br>
                        Organizatori: " . htmlspecialchars($aktivitet['organizatori']) . "<br>
                        <em>" . htmlspecialchars($aktivitet['pershkrimi_aktivitetit']) . "</em>
                      </li><br>";
            }
        } else {
            echo "<li>Aktivitete nuk janë të disponueshme.</li>";
        }
        ?>
      </ul>
    </section>
    <?php
    // Mbyllja e lidhjes me DB
    $conn->close();
    ?>
  </div>

  <footer>
    <div class="footer-inner">
      <p>© 2025 Biblioteka FA. Të gjitha të drejtat e rezervuara.</p>
    </div>
  </footer>

  <div class="chatbot-container" role="region" aria-label="Chatbot Sugjerues Librash">
    <div class="chatbot-header" tabindex="0" role="button" aria-expanded="false" aria-controls="chatBody" onclick="toggleChat()" onkeypress="if(event.key==='Enter') toggleChat()">
      💬 ChatBot - Sugjerues Librash
      <span id="chatToggleIcon" aria-hidden="true" style="font-weight:bold; margin-left: auto;">+</span>
    </div>
    <div class="chatbot-body" id="chatBody" aria-live="polite">
      <div id="chatMessages" tabindex="0"></div>
      <input
        type="text"
        id="userInput"
        placeholder="Pyet: Më sugjero një libër..."
        onkeydown="if(event.key==='Enter') sendMessage()"
        autocomplete="off"
        aria-label="Fusha për të shkruar pyetjen"
      />
    </div>
  </div>

<script>
  function toggleChat() {
    const chatBody = document.getElementById('chatBody');
    const header = document.querySelector('.chatbot-header');
    const icon = document.getElementById('chatToggleIcon');
    chatBody.classList.toggle('active');
    const expanded = chatBody.classList.contains('active');
    header.setAttribute('aria-expanded', expanded);
    icon.textContent = expanded ? '−' : '+';
    if (expanded) {
      document.getElementById('userInput').focus();
    }
  }

  function sendMessage() {
    const input = document.getElementById("userInput");
    const msg = input.value.trim();
    if (!msg) return;

    const messages = document.getElementById("chatMessages");

    const userDiv = document.createElement("div");
    userDiv.className = "chat user";
    userDiv.innerText = msg;
    messages.appendChild(userDiv);

    const msgLower = msg.toLowerCase();

    const replies = {
      histori: [
        "📘 'Historia e Ushtrise Shqiptare' – ISBN: 978-9928-10-002-2",
        "📘 'Historia e Forcave Ajrore Shqiptare' – ISBN: 978-9928-10-013-3",
        "📘 'Misionet e Ushtrise Shqiptare Jashte Vendit' – ISBN: 978-9928-10-015-5"
      ],
      strategji: [
        "🪖 'Strategjia Ushtarake Moderne' – ISBN: 978-9928-10-001-1",
        "🪖 'Doktrina Ushtarake e NATO-s' – ISBN: 978-9928-10-014-4",
        "🪖 'Udheheqja Ushtarake ne Kohe Lufte' – ISBN: 978-9928-10-012-2"
      ],
      manual: [
        "📗 'Manuali i Taktikave Tokesore' – ISBN: 978-9928-10-003-3",
        "📗 'Manual i Ushtrise per Trajnime' – ISBN: 978-9928-10-006-6",
        "📗 'Manual per Logjistiken Ushtarake' – ISBN: 978-9928-10-010-0"
      ],
      misione: [
        "🎯 'Operacionet Paqeruajtese ne Kosove' – ISBN: 978-9928-10-009-9",
        "🎯 'Stervitjet e NATO-s dhe Pjesemarja Shqiptare' – ISBN: 978-9928-10-011-1",
        "🎯 'Misionet e Ushtrise Shqiptare Jashte Vendit' – ISBN: 978-9928-10-015-5"
      ],
      teknologji: [
        "🔬 'Armatimi Modern dhe Teknologjia' – ISBN: 978-9928-10-008-8"
      ],
      biografi: [
        "📖 'Komandantet Legjendare Shqiptare' – ISBN: 978-9928-10-007-7"
      ],
      mbrojtje: [
        "🛡 'Mbrojtja dhe Siguria Kombetare' – ISBN: 978-9928-10-005-5",
        "🛡 'Forcat Speciale: Struktura dhe Funksioni' – ISBN: 978-9928-10-004-4"
      ]
    };

    let category = null;
    if (msgLower.includes("histori")) category = "histori";
    else if (msgLower.includes("strategji")) category = "strategji";
    else if (msgLower.includes("manual")) category = "manual";
    else if (msgLower.includes("mision") || msgLower.includes("operacion")) category = "misione";
    else if (msgLower.includes("teknologji") || msgLower.includes("armat")) category = "teknologji";
    else if (msgLower.includes("biografi") || msgLower.includes("komandant")) category = "biografi";
    else if (msgLower.includes("mbrojtje") || msgLower.includes("siguri") || msgLower.includes("forcat speciale")) category = "mbrojtje";

    let reply = "";

    if (category && replies[category]) {
      const suggestions = replies[category];
      const randomIndex = Math.floor(Math.random() * suggestions.length);
      reply = suggestions[randomIndex];
    } else if (msgLower.includes("faleminderit")) {
      reply = "Me kënaqësi! Nëse ke nevojë për ndihmë tjetër, jam këtu.";
    } else if (msgLower.includes("mirupafshim")) {
      reply = "Je i mirepritur sa herë të duash.";
    } else {
      reply = "❓ Nuk e gjej një libër për këtë temë. Provo me fjalë si 'strategji', 'histori', 'teknologji', 'biografi' etj.";
    }

    const botDiv = document.createElement("div");
    botDiv.className = "chat bot";
    botDiv.innerText = reply;
    messages.appendChild(botDiv);

    input.value = "";
    messages.scrollTop = messages.scrollHeight;
  }
</script>
 
</body>
</html>
