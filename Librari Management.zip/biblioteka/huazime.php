<!DOCTYPE html>
<html lang="sq">
<head>
  <meta charset="UTF-8" />
  <title>Huazimet e Librave</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
   .navbar {
      background-color: #1e3d59;
      color: white;
      display: flex;
      justify-content: space-between;
      padding: 15px 30px;
      align-items: center;
    }
    .navbar .nav-links {
      list-style: none;
      display: flex;
      gap: 20px;
    }
    .navbar .nav-links li a {
      color: #ecf0f1;
      text-decoration: none;
      font-weight: 600;
      padding: 8px 12px;
      border-radius: 6px;
      transition: background-color 0.3s ease;
    }
    .navbar .nav-links li a:hover {
       background-color: #f4f6f8;
    }
       /* Chatbot */
    .chatbot-container {
      position: fixed;
      bottom: 25px;
      right: 25px;
      width: 320px;
      max-width: 90vw;
      background: white;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.25);
      overflow: hidden;
      font-size: 14px;
      display: flex;
      flex-direction: column;
      user-select: none;
      z-index: 1000;
    }
    .chatbot-header {
      background-color: #1e3d59;
      color: white;
      padding: 14px 20px;
      font-weight: 700;
      cursor: pointer;
      user-select: none;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .chatbot-header span {
      user-select: none;
    }
    .chatbot-body {
      display: none;
      flex-direction: column;
      height: 200px;
      padding: 15px 20px;
      overflow-y: auto;
      background-color: #f0f4f8;
    }
    .chatbot-body.active {
      display: flex;
    }
    #chatMessages {
      flex-grow: 1;
      overflow-y: auto;
      margin-bottom: 12px;
      scrollbar-width: thin;
      scrollbar-color: #a5d6a7 transparent;
    }
    #chatMessages::-webkit-scrollbar {
      width: 6px;
    }
    #chatMessages::-webkit-scrollbar-thumb {
      background-color: #a5d6a7;
      border-radius: 10px;
    }
    .chat {
      padding: 10px 14px;
      border-radius: 20px;
      max-width: 85%;
      margin-bottom: 10px;
      word-wrap: break-word;
      line-height: 1.3;
      font-size: 14px;
    }
    .user {
      background-color: #dfe6e9;
      align-self: flex-end;
      border-bottom-right-radius: 4px;
    }
    .bot {
      background-color: #a5d6a7;
      align-self: flex-start;
      border-bottom-left-radius: 4px;
    }
    #userInput {
      border: 1px solid #ccc;
      border-radius: 25px;
      padding: 10px 18px;
      font-size: 14px;
      width: 100%;
      outline: none;
      transition: border-color 0.3s ease;
    }
    #userInput:focus {
      border-color: #2a9d8f;
    }

         
    .main-content {
      max-width: 1000px;
      margin: 40px auto;
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    table, th, td {
      border: 1px solid #ccc;
    }
    th, td {
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #2980b9;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>

  <nav class="navbar">
    <div class="logo">📚 Biblioteka FA</div>
    <ul class="nav-links">
      <li><a href="index.html">Home</a></li>
    </ul>
  </nav>

  <div class="main-content">
    <h2>📘 Lista e Huazimeve</h2>
    <table>
        <a href="huazim_shto.php" style="float: right; margin-bottom: 15px; display: inline-block; background: #0a9396; color: white; padding: 8px 16px; border-radius: 6px; text-decoration: none;">+ Shto Huazim</a>
      <thead>
        <tr>
          <th>Anëtari</th>
          <th>Libri</th>
          <th>Data e Huazimit</th>
          <th>Data e Kthimit</th>
          <th>Statusi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $conn = new mysqli("localhost", "root", "", "biblioteka");
        if ($conn->connect_error) {
            die("Lidhja dështoi: " . $conn->connect_error);
        }

        $sql = "
          SELECT 
            CONCAT(A.emri, ' ', A.mbiemri) AS anetari,
            L.titulli AS libri,
            H.data_huazimit,
            H.data_kthimit,
            H.statusi
          FROM Huazim H
          JOIN Anetar A ON H.id_anetar = A.id_anetar
          JOIN Libri L ON H.id_libri = L.id_libri
          ORDER BY H.data_huazimit DESC
        ";

        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . htmlspecialchars($row['anetari']) . "</td>
                        <td>" . htmlspecialchars($row['libri']) . "</td>
                        <td>" . htmlspecialchars($row['data_huazimit']) . "</td>
                        <td>" . htmlspecialchars($row['data_kthimit']) . "</td>
                        <td>" . htmlspecialchars($row['statusi']) . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Asnjë huazim i regjistruar.</td></tr>";
        }

        $conn->close();
        ?>
      </tbody>
    </table>
  </div>
  <div class="chatbot-container" role="region" aria-label="Chatbot Sugjerues Librash">
    <div class="chatbot-header" tabindex="0" role="button" aria-expanded="false" aria-controls="chatBody" onclick="toggleChat()" onkeypress="if(event.key==='Enter') toggleChat()">
      💬 ChatBot - Sugjerues Librash
      <span id="chatToggleIcon" aria-hidden="true" style="font-weight:bold; margin-left: auto;">+</span>
    </div>
    <div class="chatbot-body" id="chatBody" aria-live="polite">
      <div id="chatMessages" tabindex="0"></div>
      <input
        type="text"
        id="userInput"
        placeholder="Pyet: Më sugjero një libër..."
        onkeydown="if(event.key==='Enter') sendMessage()"
        autocomplete="off"
        aria-label="Fusha për të shkruar pyetjen"
      />
    </div>
  </div>

<script>
    function toggleChat() {
      const chatBody = document.getElementById('chatBody');
      const header = document.querySelector('.chatbot-header');
      const icon = document.getElementById('chatToggleIcon');
      chatBody.classList.toggle('active');
      const expanded = chatBody.classList.contains('active');
      header.setAttribute('aria-expanded', expanded);
      icon.textContent = expanded ? '−' : '+';
      if (expanded) {
        document.getElementById('userInput').focus();
      }
    }

    function sendMessage() {
      const input = document.getElementById("userInput");
      const msg = input.value.trim();
      if (!msg) return;

      const messages = document.getElementById("chatMessages");

      const userDiv = document.createElement("div");
      userDiv.className = "chat user";
      userDiv.innerText = msg;
      messages.appendChild(userDiv);

      const msgLower = msg.toLowerCase();

         const replies = {
  histori: [
    "📘 'Historia e Ushtrise Shqiptare' – ISBN: 978-9928-10-002-2",
    "📘 'Historia e Forcave Ajrore Shqiptare' – ISBN: 978-9928-10-013-3",
    "📘 'Misionet e Ushtrise Shqiptare Jashte Vendit' – ISBN: 978-9928-10-015-5"
  ],
  strategji: [
    "🪖 'Strategjia Ushtarake Moderne' – ISBN: 978-9928-10-001-1",
    "🪖 'Doktrina Ushtarake e NATO-s' – ISBN: 978-9928-10-014-4",
    "🪖 'Udheheqja Ushtarake ne Kohe Lufte' – ISBN: 978-9928-10-012-2"
  ],
  manual: [
    "📗 'Manuali i Taktikave Tokesore' – ISBN: 978-9928-10-003-3",
    "📗 'Manual i Ushtrise per Trajnime' – ISBN: 978-9928-10-006-6",
    "📗 'Manual per Logjistiken Ushtarake' – ISBN: 978-9928-10-010-0"
  ],
  misione: [
    "🎯 'Operacionet Paqeruajtese ne Kosove' – ISBN: 978-9928-10-009-9",
    "🎯 'Stervitjet e NATO-s dhe Pjesemarja Shqiptare' – ISBN: 978-9928-10-011-1",
    "🎯 'Misionet e Ushtrise Shqiptare Jashte Vendit' – ISBN: 978-9928-10-015-5"
  ],
  teknologji: [
    "🔬 'Armatimi Modern dhe Teknologjia' – ISBN: 978-9928-10-008-8"
  ],
  biografi: [
    "📖 'Komandantet Legjendare Shqiptare' – ISBN: 978-9928-10-007-7"
  ],
  mbrojtje: [
    "🛡 'Mbrojtja dhe Siguria Kombetare' – ISBN: 978-9928-10-005-5",
    "🛡 'Forcat Speciale: Struktura dhe Funksioni' – ISBN: 978-9928-10-004-4"
  ]
};

    

     let category = null;
if (msgLower.includes("histori")) category = "histori";
else if (msgLower.includes("strategji")) category = "strategji";
else if (msgLower.includes("manual")) category = "manual";
else if (msgLower.includes("mision") || msgLower.includes("operacion")) category = "misione";
else if (msgLower.includes("teknologji") || msgLower.includes("armat")) category = "teknologji";
else if (msgLower.includes("biografi") || msgLower.includes("komandant")) category = "biografi";
else if (msgLower.includes("mbrojtje") || msgLower.includes("siguri") || msgLower.includes("forcat speciale")) category = "mbrojtje";
      let reply = "";

      if (category && replies[category]) {
        const suggestions = replies[category];
        const randomIndex = Math.floor(Math.random() * suggestions.length);
        reply = suggestions[randomIndex];
      } else if (msgLower.includes("faleminderit")) {
        reply = "Me kënaqësi! Nëse ke nevojë për ndihmë tjetër, jam këtu.";
      } else if (msgLower.includes("mirupafshim")) {
        reply = "Je i mirepritur sa herë të duash.";
      } else {
        reply = "❓ Nuk e gjej një libër për këtë temë. Provo me fjalë si 'strategji', 'histori', 'teknologji', 'biografi' etj.";
      }

      const botDiv = document.createElement("div");
      botDiv.className = "chat bot";
      botDiv.innerText = reply;
      messages.appendChild(botDiv);

      input.value = "";
      messages.scrollTop = messages.scrollHeight;
    }
  </script>

</body>
</html>
