<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteka";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Lidhja dështoi: " . $conn->connect_error);
}

$email = $_POST['email'];

// Kontrollo nëse email ekziston
$checkQuery = "SELECT * FROM Anetar WHERE email = ?";
$checkStmt = $conn->prepare($checkQuery);
$checkStmt->bind_param("s", $email);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows > 0) {
    echo "<script>alert('Ky email është regjistruar më parë!'); window.location.href='anetar_regjistrim.html';</script>";
    exit;
}

// Nëse nuk ekziston → vazhdo regjistrimin
$emri = $_POST['emri'];
$mbiemri = $_POST['mbiemri'];
$datelindja = $_POST['datelindja'];
$vendlindja = $_POST['vendlindja'];
$status = $_POST['status_anetari'];
$adresa = $_POST['adresa'];
$nr_tel = $_POST['nr_tel'];
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "INSERT INTO Anetar (emri, mbiemri, datelindja, vendlindja, status_anetari, adresa, email, nr_tel,username,password)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssssss", $emri, $mbiemri, $datelindja, $vendlindja, $status, $adresa, $email, $nr_tel, $username ,
$password);

if ($stmt->execute()) {
    // Ridrejto pas regjistrimit të suksesshëm
    header("Location: libri_dashboard.php");
    exit;
} else {
    echo "Gabim gjatë regjistrimit: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
