<?php
session_start();
if (!isset($_SESSION['staf_username'])) {
    header("Location: login_staf.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="sq">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Paneli i Stafit - Biblioteka FA</title>
  <style>
    /* Reset bazik */
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      background: #f0f2f5;
      color: #333;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-bottom: 60px; /* hapësirë për chatbot ose footer */
    }

    /* Navbar */
    nav.navbar {
      width: 100%;
      background: #2c3e50;
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: #ecf0f1;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    nav .logo {
      font-size: 1.5rem;
      font-weight: 700;
      color: #e76f51;
    }

    nav .nav-links {
      list-style: none;
      display: flex;
      gap: 20px;
    }

    nav .nav-links li a {
      color: #ecf0f1;
      text-decoration: none;
      font-weight: 600;
      padding: 8px 12px;
      border-radius: 6px;
      transition: background-color 0.3s ease;
    }

    nav .nav-links li a:hover {
      background-color: #34495e;
    }

    /* Main container */
    .container {
      background: #fff;
      padding: 30px 40px;
      margin: 40px 20px;
      max-width: 600px;
      width: 100%;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
      text-align: center;
      animation: fadeInUp 0.7s ease forwards;
    }

    .container h2 {
      margin-bottom: 20px;
      color: #2c3e50;
      font-weight: 700;
      font-size: 2rem;
      letter-spacing: 1px;
    }

    .container p {
      font-size: 1.1rem;
      margin-bottom: 30px;
    }

    .btn-logout {
      display: inline-block;
      padding: 12px 25px;
      background-color: #e76f51;
      color: white;
      font-weight: 700;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }

    .btn-logout:hover {
      background-color: #d65a3a;
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

  </style>
</head>
<body>

<nav class="navbar">
  <div class="logo">📚 Biblioteka FA</div>
  <ul class="nav-links">
    <li><a href="index.html">Home</a></li>
    <li><a href="huazime.php">Huazime</a></li>
  </ul>
</nav>

<div class="container">
  <h2>Mirësevini, <?php echo htmlspecialchars($_SESSION['staf_username']); ?>!</h2>
  <p>Kjo është faqja e brendshme e stafit.</p>
  <a href="logout_staf.php" class="btn-logout">Log Out</a>
</div>

</body>
</html>

