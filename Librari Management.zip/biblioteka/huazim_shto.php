<!DOCTYPE html>
<html lang="sq">
<head>
  <meta charset="UTF-8" />
  <title>Shto Huazim</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      padding: 30px;
    }
    .form-container {
      max-width: 600px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.2);
    }
    h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #0a9396;
    }
    label {
      display: block;
      margin-top: 15px;
      font-weight: bold;
    }
    select, input[type="date"], input[type="text"] {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    button {
      margin-top: 25px;
      padding: 12px;
      background-color: #0a9396;
      color: white;
      border: none;
      width: 100%;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
    }
    button:hover {
      background-color: #00707d;
    }
  </style>
</head>
<body>

  <div class="form-container">
    <h2>Shto Huazim të Ri</h2>
    <form action="huazim_insert.php" method="POST">
      <label>Zgjidh Anëtarin:</label>
      <select name="id_anetar" required>
        <?php
        $conn = new mysqli("localhost", "root", "", "biblioteka");
        $result = $conn->query("SELECT id_anetar, emri, mbiemri FROM Anetar");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['id_anetar']}'>" . htmlspecialchars($row['emri'] . ' ' . $row['mbiemri']) . "</option>";
        }
        ?>
      </select>

      <label>Zgjidh Librin:</label>
      <select name="id_libri" required>
        <?php
        $result = $conn->query("SELECT id_libri, titulli FROM Libri");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['id_libri']}'>" . htmlspecialchars($row['titulli']) . "</option>";
        }
        ?>
      </select>

      <label>Data e Huazimit:</label>
      <input type="date" name="data_huazimit" required value="<?= date('Y-m-d') ?>">

      <label>Data e Kthimit (afërsisht):</label>
      <input type="date" name="data_kthimit" required>

      <label>Statusi:</label>
      <select name="statusi">
        <option value="aktiv">Aktiv</option>
        <option value="kthyer">Kthyer</option>
        <option value="vonesë">Vonesë</option>
      </select>

      <button type="submit">Shto Huazim</button>
    </form>
  </div>
 <div class="chatbot-container">
  <div class="chatbot-header" onclick="toggleChat()">💬 ChatBot - Sugjerues Librash</div>
  <div class="chatbot-body" id="chatBody">
    <div id="chatMessages"></div>
    <input type="text" id="userInput" placeholder="Pyet: Më sugjero një libër..." onkeydown="if(event.key==='Enter') sendMessage()">
  </div>
</div>

<script>
  function toggleChat() {
    document.getElementById("chatBody").classList.toggle("active");
  }

  function sendMessage() {
    const input = document.getElementById("userInput");
    const msg = input.value.trim();
    if (!msg) return;

    const messages = document.getElementById("chatMessages");
    const userDiv = document.createElement("div");
    userDiv.className = "chat user";
    userDiv.innerText = msg;
    messages.appendChild(userDiv);

    // Sugjerime bazike (mund t’i zëvendësojmë me logjikë më vonë)
    let reply = "Nuk jam i sigurt, mund të kërkosh tek biblioteka.";

    if (msg.toLowerCase().includes("histori")) {
      reply = "Sugjerim: 'Historia Ushtarake e Shqiptarëve' - Uran Butka.";
    } else if (msg.toLowerCase().includes("teknologji")) {
      reply = "Sugjerim: 'Revolucioni Dixhital' - Eric Schmidt.";
    } else if (msg.toLowerCase().includes("roman") || msg.toLowerCase().includes("letërsi")) {
      reply = "Sugjerim: 'Gjenerali i Ushtrisë së Vdekur' - Ismail Kadare.";
    }

    const botDiv = document.createElement("div");
    botDiv.className = "chat bot";
    botDiv.innerText = reply;
    messages.appendChild(botDiv);

    input.value = "";
    messages.scrollTop = messages.scrollHeight;
  }
</script>

</body>
</html>
