<?php
header('Content-Type: application/json');

if(!isset($_GET['email']) || empty($_GET['email'])){
  echo json_encode(['success' => false]);
  exit;
}

$email = $_GET['email'];

// Parametrat e DB-së (ndrysho sipas konfigurimit tënd)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteka";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  echo json_encode(['success' => false]);
  exit;
}

$stmt = $conn->prepare("SELECT id_anetar FROM Anetar WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($id_anetar);

if ($stmt->fetch()) {
  echo json_encode(['success' => true, 'id_anetar' => $id_anetar]);
} else {
  echo json_encode(['success' => false]);
}

$stmt->close();
$conn->close();
