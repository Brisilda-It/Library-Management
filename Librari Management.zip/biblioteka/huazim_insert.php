<?php
$conn = new mysqli("localhost", "root", "", "biblioteka");
if ($conn->connect_error) {
    die("Lidhja dështoi: " . $conn->connect_error);
}

$id_anetar = $_POST['id_anetar'];
$id_libri = $_POST['id_libri'];
$data_huazimit = $_POST['data_huazimit'];
$data_kthimit = $_POST['data_kthimit'];
$statusi = $_POST['statusi'];

$stmt = $conn->prepare("INSERT INTO Huazim (id_anetar, id_libri, data_huazimit, data_kthimit, statusi) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("iisss", $id_anetar, $id_libri, $data_huazimit, $data_kthimit, $statusi);

if ($stmt->execute()) {
    echo "<script>alert('Huazimi u regjistrua me sukses!'); window.location.href='huazime.php';</script>";
} else {
    echo "Gabim gjatë regjistrimit: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
