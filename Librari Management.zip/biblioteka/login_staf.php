<?php
// Lidhja me databazën
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'biblioteka';

$conn = new mysqli($host, $user, $pass, $dbname);

// Kontrollo lidhjen
if ($conn->connect_error) {
    die("Lidhja dështoi: " . $conn->connect_error);
}

// Merr të dhënat nga forma
$username = $_POST['username'];
$password = $_POST['password'];

// Kontrollo në databazë
$sql = "SELECT * FROM Stafi_Mbeshtetes WHERE username = ? AND password = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

// Nëse ekziston
if ($result->num_rows == 1) {
    session_start();
    $_SESSION['staf_username'] = $username;
    header("Location: dashboard_staf.php");
    exit();
} else {
    echo "<script>alert('Emri ose fjalëkalimi është i pasaktë!'); window.location.href='login_staf.html';</script>";
}

$stmt->close();
$conn->close();
?>
