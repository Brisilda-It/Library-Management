<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteka";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  echo "<script>alert('❌ Lidhja me databazën dështoi: " . addslashes($conn->connect_error) . "'); window.location.href='kerkese_huazimi.html';</script>";
  exit;
}

$id_anetar = $_POST['id_anetar'] ?? '';
$emri_anetarit = $_POST['emri_anetarit'] ?? '';
$email_anetari = $_POST['email_anetari'] ?? '';
$titulli_librit = $_POST['titulli_librit'] ?? '';

if (empty($id_anetar)) {
  echo "<script>alert('❌ ID e anëtarit mungon!'); window.location.href='kerkese_huazimi.html';</script>";
  exit;
}

$email_check = $conn->prepare("SELECT 1 FROM KerkesaHuazimi WHERE email_anetari = ?");
$email_check->bind_param("s", $email_anetari);
$email_check->execute();
$email_check->store_result();

if ($email_check->num_rows > 0) {
  echo "<script>alert('❌ Ky email është regjistruar më parë për një kërkesë!'); window.location.href='kerkese_huazimi.html';</script>";
  $email_check->close();
  $conn->close();
  exit;
}
$email_check->close();

$sql = "INSERT INTO KerkesaHuazimi (id_anetar, emri_anetarit, email_anetari, titulli_librit) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
  echo "<script>alert('❌ Gabim në përgatitjen e kërkesës: " . addslashes($conn->error) . "'); window.location.href='kerkese_huazimi.html';</script>";
  exit;
}

$stmt->bind_param("isss", $id_anetar, $emri_anetarit, $email_anetari, $titulli_librit);

if ($stmt->execute()) {
  echo "<script>alert('✅ Kërkesa u regjistrua me sukses!'); window.location.href='kerkese_huazimi.html';</script>";
} else {
  echo "<script>alert('❌ Gabim gjatë regjistrimit: " . addslashes($stmt->error) . "'); window.location.href='kerkese_huazimi.html';</script>";
}

$stmt->close();
$conn->close();
?>
